﻿namespace Project1_Elevator
{
    internal class Global
    {
        //1-> Opening
        //2-> Stop
        //3-> Closing
        public static int DOOR_STATE = 0;

    
}
}

